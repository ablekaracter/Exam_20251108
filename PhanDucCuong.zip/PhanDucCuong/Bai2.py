N=int(input("Nhap nam ban muon "))
if N%4==0 and N%100==0:
    print("Nam ban nhap la nam nhuan")
elif N%400==0 :
    print("Nam ban nhap la nam nhuan")
else :
    print("Nam ban nhap khong phai nam nhuan")