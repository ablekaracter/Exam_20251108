N = (input("Nhap mat khau moi "))
M = (input("Xac nhan mat khau moi lan 2 "))
if N != M :
    print("Mat khau khong giong nhau")
else:
    print("Mau khai da duoc doi thanh cong")