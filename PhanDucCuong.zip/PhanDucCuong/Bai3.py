N = int(input("Gia tri nhiet do:"))
if N > 30 :
    print("Troi dang nong")
elif N < 20 :
    print("Troi dang lanh")
else:
    print("Thoi tiet de chiu")
