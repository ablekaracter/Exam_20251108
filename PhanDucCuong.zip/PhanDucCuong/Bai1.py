
a=int(input("Nhap so a: "))
b=int(input("Nhap so b: "))
c=int(input("Nhap so c: "))
if a == b and b == c and c == a:
    print("Cac so deu bang nhau")
elif a<b and a<c :
    print(" a la so be nhat ")
elif b<a and b<c : 
    print("b la so be nhat")
else :
    print("c la so be nhat")
    