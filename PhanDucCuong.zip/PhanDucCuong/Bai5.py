N = float(input("Nhap so km ban da di: "))
if N < 1 :
    print("So tien ban phai tra 7000d/km")
elif N>1 and N<5 :
    tong = (N-1)*6500 + 7000
    print("So tien ban phai tra",tong)
else :
    tong = (N-6)*6000 + 6500 + 7000
    print("So tien ban phai tra",tong)
